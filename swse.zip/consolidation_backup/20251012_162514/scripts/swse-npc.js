// ============================================
// FILE: scripts/swse-npc.js
// ============================================
import { SWSEActorSheet } from "./swse-actor.js";
... (rest of your JS code from npc file) ...
