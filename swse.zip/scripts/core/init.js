/**
 * SWSE Init — placeholder to satisfy Foundry system validation
 */
Hooks.once("init", () => {
  console.log("SWSE system initialized successfully.");
});
