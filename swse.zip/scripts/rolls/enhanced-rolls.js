import { DamageSystem } from '../combat/damage-system.js';

/**
 * Enhanced Roll System for SWSE
 * This integrates with the actor system and automatically applies
 * condition penalties, Force Point bonuses, and other modifiers.
 */
export class SWSERoll {

  /**
   * Roll an attack with a weapon
   * This automatically includes BAB, ability mod, condition penalties, etc.
   */
  static async rollAttack(actor, weapon, options = {}) {
    const rollData = actor.getRollData();

    // Build the formula step by step so we can see what's happening
    let formula = '1d20';
    let parts = [];

    // Base Attack Bonus
    if (actor.system.bab) {
      formula += ' + @bab';
      parts.push(`BAB ${actor.system.bab >= 0 ? '+' : ''}${actor.system.bab}`);
    }

    // Ability modifier (STR for melee, DEX for ranged)
    const abilityKey = weapon.system.attackAttribute || 'str';
    formula += ` + @${abilityKey}`;
    parts.push(`${abilityKey.toUpperCase()} ${rollData[abilityKey] >= 0 ? '+' : ''}${rollData[abilityKey]}`);

    // Weapon bonus
    if (weapon.system.attackBonus) {
      formula += ` + ${weapon.system.attackBonus}`;
      parts.push(`Weapon +${weapon.system.attackBonus}`);
    }

    // Condition penalty (automatically applied)
    if (rollData.conditionPenalty) {
      formula += ' + @conditionPenalty';
      parts.push(`Condition ${rollData.conditionPenalty}`);
    }

    // Create and evaluate the roll
    const roll = new Roll(formula, rollData);
    await roll.evaluate({async: true});

    // Check for critical threat
    const d20Result = roll.terms[0].results[0].result;
    const isCrit = d20Result >= (weapon.system.critRange || 20);

    // Create detailed message
    const messageContent = `
      <div class="swse-attack-roll ${isCrit ? 'critical-threat' : ''}">
        <div class="roll-header">
          <img src="${weapon.img}" alt="${weapon.name}">
          <h3>${weapon.name} Attack</h3>
        </div>
        <div class="roll-result">
          <h4 class="dice-total">${roll.total}</h4>
          <div class="dice-formula">${roll.formula}</div>
        </div>
        <div class="roll-breakdown">
          <div class="dice-rolls">d20: ${d20Result}</div>
          <div class="modifiers">${parts.join(', ')}</div>
        </div>
        ${isCrit ? '<div class="crit-indicator">CRITICAL THREAT!</div>' : ''}
        <div class="roll-actions">
          <button class="roll-damage" data-weapon-id="${weapon.id}">
            <i class="fas fa-burst"></i> Roll Damage
          </button>
        </div>
      </div>
    `;

    const message = await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({actor: actor}),
      content: messageContent,
      roll: roll,
      sound: CONFIG.sounds.dice
    });

    // Dice So Nice integration
    if (game.dice3d) {
      await game.dice3d.showForRoll(roll, game.user, true);
    }

    return {roll, message, isCrit};
  }

  /**
   * Roll damage for a weapon
   */
  static async rollDamage(actor, weapon, options = {}) {
    const rollData = actor.getRollData();

    // Start with base damage
    let formula = weapon.system.damage || '1d6';
    let parts = [];

    // Add ability modifier for melee
    if (!weapon.system.ranged) {
      const strMod = rollData.str;
      formula += ' + @str';
      parts.push(`STR ${strMod >= 0 ? '+' : ''}${strMod}`);
    }

    // Add half level (heroic characters only)
    if (actor.type === 'character') {
      formula += ' + @halfLevel';
      parts.push(`½ Level +${rollData.halfLevel}`);
    }

    // Critical hit?
    if (options.critical) {
      formula = `(${formula}) * 2`;
      parts.push('CRITICAL!');
    }

    const roll = new Roll(formula, rollData);
    await roll.evaluate({async: true});

    const messageContent = `
      <div class="swse-damage-roll">
        <div class="roll-header">
          <img src="${weapon.img}" alt="${weapon.name}">
          <h3>${weapon.name} Damage</h3>
        </div>
        <div class="roll-result">
          <h4 class="dice-total">${roll.total}</h4>
          <div class="damage-type">${weapon.system.damageType || 'energy'}</div>
        </div>
        <div class="roll-breakdown">
          <div class="dice-formula">${roll.formula}</div>
          <div class="modifiers">${parts.join(', ')}</div>
        </div>
        <div class="damage-application">
          <button class="apply-damage" data-damage="${roll.total}">
            <i class="fas fa-heart-broken"></i> Apply to Target
          </button>
        </div>
      </div>
    `;

    const message = await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({actor: actor}),
      content: messageContent,
      roll: roll,
      sound: CONFIG.sounds.dice
    });

    if (game.dice3d) {
      await game.dice3d.showForRoll(roll, game.user, true);
    }

    return {roll, message};
  }

  /**
   * Roll a skill check
   */
  static async rollSkill(actor, skillKey, options = {}) {
    const skill = actor.system.skills[skillKey];
    if (!skill) {
      ui.notifications.warn(`Skill ${skillKey} not found`);
      return;
    }

    const rollData = actor.getRollData();

    // Build formula
    let formula = '1d20';
    let parts = [];

    // Add skill total (includes everything)
    formula += ` + ${skill.total}`;

    // Build breakdown
    const halfLevel = Math.floor(actor.system.level / 2);
    parts.push(`½ Level +${halfLevel}`);

    if (skill.trained) {
      parts.push('Trained +5');
    }

    if (skill.focus > 0) {
      parts.push(`Focus +${skill.focus * 5}`);
    }

    if (rollData.conditionPenalty) {
      parts.push(`Condition ${rollData.conditionPenalty}`);
    }

    const roll = new Roll(formula, rollData);
    await roll.evaluate({async: true});

    // Skill check results can be compared to DCs
    const dcExamples = {
      easy: 10,
      medium: 15,
      hard: 20,
      heroic: 25
    };

    let successLevel = '';
    for (const [level, dc] of Object.entries(dcExamples)) {
      if (roll.total >= dc) {
        successLevel = level;
      }
    }

    const messageContent = `
      <div class="swse-skill-roll">
        <div class="roll-header">
          <h3>${skillKey.charAt(0).toUpperCase() + skillKey.slice(1)} Check</h3>
        </div>
        <div class="roll-result">
          <h4 class="dice-total">${roll.total}</h4>
          <div class="success-level">Beats ${successLevel.toUpperCase()} DC</div>
        </div>
        <div class="roll-breakdown">
          <div class="modifiers">${parts.join(', ')}</div>
        </div>
      </div>
    `;

    const message = await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({actor: actor}),
      content: messageContent,
      roll: roll,
      sound: CONFIG.sounds.dice
    });

    if (game.dice3d) {
      await game.dice3d.showForRoll(roll, game.user, true);
    }

    return {roll, message};
  }

  /**
   * Roll Use the Force check
   */
  static async rollUseTheForce(actor, power, options = {}) {
    const skill = actor.system.skills.useTheForce;

    if (!skill || !skill.trained) {
      ui.notifications.warn('Use the Force requires training!');
      return;
    }

    const dc = power.system.useTheForce || 15;
    const rollData = actor.getRollData();

    const roll = new Roll(`1d20 + ${skill.total}`, rollData);
    await roll.evaluate({async: true});

    const success = roll.total >= dc;

    const messageContent = `
      <div class="swse-force-roll ${success ? 'success' : 'failure'}">
        <div class="roll-header">
          <img src="${power.img}" alt="${power.name}">
          <h3>Use the Force: ${power.name}</h3>
        </div>
        <div class="roll-result">
          <h4 class="dice-total">${roll.total}</h4>
          <div class="dc-target">DC ${dc}</div>
          <div class="result ${success ? 'success' : 'failure'}">
            ${success ? '✓ SUCCESS' : '✗ FAILURE'}
          </div>
        </div>
        ${success ? `
          <div class="power-effect">
            ${power.system.effect || ''}
          </div>
        ` : ''}
      </div>
    `;

    const message = await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({actor: actor}),
      content: messageContent,
      roll: roll,
      sound: CONFIG.sounds.dice
    });

    if (game.dice3d) {
      await game.dice3d.showForRoll(roll, game.user, true);
    }

    // Apply Force Point cost if successful
    if (success && power.system.forcePointCost) {
      await actor.spendForcePoint(`activating ${power.name}`);
    }

    return {roll, message, success};
  }
}

// Make available globally for macros and modules
window.SWSERoll = SWSERoll;

// Hook into chat messages to handle button clicks
Hooks.on('renderChatMessage', (message, html) => {
  // Roll damage button
  html.find('.roll-damage').click(async (event) => {
    const weaponId = event.currentTarget.dataset.weaponId;
    const speaker = message.speaker;
    const actor = game.actors.get(speaker.actor);
    const weapon = actor?.items.get(weaponId);

    if (actor && weapon) {
      await SWSERoll.rollDamage(actor, weapon);
    }
  });

  // Apply damage button
  html.find('.apply-damage').click(async (event) => {
    const damage = parseInt(event.currentTarget.dataset.damage);
    const tokens = canvas.tokens.controlled;

    if (tokens.length === 0) {
      ui.notifications.warn('Select target token(s) first');
      return;
    }

    for (const token of tokens) {
      await token.actor.applyDamage(damage, {checkThreshold: true});
    }
  });
});
