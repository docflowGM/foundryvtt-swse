// SWSE NPC Actor
export default class SWSENPCActor {
    constructor(actor) {
        this.actor = actor;
    }
    
    // Add NPC-specific methods here
}
