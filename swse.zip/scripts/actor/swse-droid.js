// SWSE Droid Actor  
export default class SWSEDroidActor {
    constructor(actor) {
        this.actor = actor;
    }
    
    // Add Droid-specific methods here
}
