// SWSE Vehicle Actor
export default class SWSEVehicleActor {
    constructor(actor) {
        this.actor = actor;
    }
    
    // Add Vehicle-specific methods here
}
