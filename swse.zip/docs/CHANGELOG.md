# Changelog
All notable changes to this project will be documented here.

## [2025-11-04]
- Repo auto-maintained using `maintain_swse_repo.py`
- Validated system.json, created missing documentation, checked compendia
