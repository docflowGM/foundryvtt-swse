# FoundryVTT SWSE System
This repository contains a Star Wars Saga Edition system for Foundry Virtual Tabletop.
