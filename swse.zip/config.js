// ============================================
// FILE: config.js
// ============================================
export const SWSE = {};

SWSE.actorTypes = ["character", "droid", "vehicle", "npc"];
SWSE.itemTypes = ["armor", "attribute", "class", "combat-action", "equipment", "extra-skill-use", "feat", "forcepower", "skill", "species", "talent", "talenttree", "weapon"];
