// ============================================
// FILE: config.js
// ============================================
export const SWSE = {};

SWSE.actorTypes = ["character", "droid", "vehicle", "npc"];
SWSE.itemTypes = ["armor", "class", "equipment", "feat", "forcepower", "talent", "weapon", "skill", "attribute", "equipment", "combat-action", "extra-skill-use"];
