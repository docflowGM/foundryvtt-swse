/**
 * ==============================================
 * SWSE Character Sheet - Event Handlers
 * Handles sheet type switching and tab navigation
 * ==============================================
 */

/**
 * Initialize sheet event listeners
 * Call this when the sheet renders
 */
export function initializeSheetHandlers(html, actor) {
  // Sheet type switching
  initializeSheetTypeSwitching(html);
  
  // Bottom tabs navigation
  initializeBottomTabs(html);
  
  // Condition track buttons
  initializeConditionTrack(html, actor);
  
  // Skill roll buttons
  initializeSkillRolls(html, actor);
  
  // Attribute roll buttons
  initializeAttributeRolls(html, actor);
}

/**
 * Handle sheet type switching (PC / NPC / Vehicle / Droid)
 */
function initializeSheetTypeSwitching(html) {
  const sheetForm = html.find('.swse-datapad-sheet');
  const headerTabs = html.find('.header-tab');

  headerTabs.on('click', (event) => {
    const button = $(event.currentTarget);
    const mode = button.data('sheet-mode');

    // Update active state
    headerTabs.removeClass('active');
    button.addClass('active');

    // Update sheet mode attribute
    sheetForm.attr('data-sheet-mode', mode);

    // Optional: Save mode to actor flags for persistence
    // actor.setFlag('swse', 'sheetMode', mode);

    console.log(`Switched to ${mode} sheet mode`);
  });
}

/**
 * Handle bottom tabs navigation (Eqassets/uipment / Feats / Talents / Powers / Notes)
 */
function initializeBottomTabs(html) {
  const tabButtons = html.find('.bottom-tab');
  const tabContents = html.find('.bottom-tab-content');

  tabButtons.on('click', (event) => {
    const button = $(event.currentTarget);
    const targetTab = button.data('tab');

    // Update active states
    tabButtons.removeClass('active');
    button.addClass('active');

    // Show/hide content
    tabContents.removeClass('active').hide();
    html.find(`.bottom-tab-content[data-tab="${targetTab}"]`).addClass('active').show();
  });
}

/**
 * Handle condition track button clicks
 */
function initializeConditionTrack(html, actor) {
  const conditionButtons = html.find('.condition-btn');
  const conditionInput = html.find('input[name="system.condition"]');

  conditionButtons.on('click', async (event) => {
    const button = $(event.currentTarget);
    const condition = button.data('condition');

    // Update active state
    conditionButtons.removeClass('active');
    button.addClass('active');

    // Update hidden input
    conditionInput.val(condition);

    // Update actor
    if (actor) {
      await actor.update({ 'system.condition': condition });
      assets/ui.notifications.info(`Condition set to: ${condition}`);
    }
  });
}

/**
 * Handle skill roll buttons
 */
function initializeSkillRolls(html, actor) {
  html.find('.skill-row .roll-btn-sm').on('click', async (event) => {
    event.preventDefault();
    const button = $(event.currentTarget);
    const skillKey = button.data('skill');

    if (!actor) return;

    // Use the rollSkill function from your skills.js
    if (game.swse?.rolls?.rollSkill) {
      await game.swse.rolls.rollSkill(actor, skillKey);
    } else {
      // Fallback basic roll
      const skill = actor.system.skills?.[skillKey];
      if (skill && skill.total !== undefined) {
        const roll = await new Roll(`1d20 + ${skill.total}`).evaluate({ async: true });
        await roll.toMessage({
          speaker: ChatMessage.getSpeaker({ actor }),
          flavor: `${skillKey} Check`
        });
      } else {
        assets/ui.notifications.warn(`Skill ${skillKey} not found or total not calculated`);
      }
    }
  });
}

/**
 * Handle attribute roll buttons
 */
function initializeAttributeRolls(html, actor) {
  html.find('.attribute-row-improved .roll-btn').on('click', async (event) => {
    event.preventDefault();
    const button = $(event.currentTarget);
    const abilityKey = button.data('ability');

    if (!actor) return;

    const ability = actor.system.abilities?.[abilityKey];
    if (!ability || ability.mod === undefined) {
      assets/ui.notifications.warn(`Ability ${abilityKey} not found`);
      return;
    }

    const roll = await new Roll(`1d20 + ${ability.mod}`).evaluate({ async: true });
    await roll.toMessage({
      speaker: ChatMessage.getSpeaker({ actor }),
      flavor: `${abilityKey.toUpperCase()} Check (${ability.mod >= 0 ? '+' : ''}${ability.mod})`
    });
  });
}

/**
 * Handle initiative roll button
 */
export function initializeInitiativeRoll(html, actor) {
  html.find('button[data-roll="initiative"]').on('click', async (event) => {
    event.preventDefault();

    if (!actor) return;

    // Get initiative modifier from actor
    const initiativeSkill = actor.system.skills?.initiative;
    const initMod = initiativeSkill?.total || 0;

    const roll = await new Roll(`1d20 + ${initMod}`).evaluate({ async: true });
    await roll.toMessage({
      speaker: ChatMessage.getSpeaker({ actor }),
      flavor: `Initiative (${initMod >= 0 ? '+' : ''}${initMod})`
    });
  });
}

/**
 * Handle portrait click to open file picker
 */
export function initializePortraitClick(html, actor) {
  html.find('.character-portrait').on('click', async (event) => {
    event.preventDefault();
    
    if (!actor) return;

    const fp = new FilePicker({
      type: "image",
      current: actor.img,
      callback: async (path) => {
        await actor.update({ img: path });
      }
    });
    
    fp.browse();
  });
}

/**
 * Handle add eqassets/uipment button
 */
export function initializeAddEqassets/uipment(html, actor) {
  html.find('.add-eqassets/uipment-btn').on('click', async (event) => {
    event.preventDefault();
    
    if (!actor) return;

    // Open compendium or item browser
    // This is a placeholder - implement according to your system
    assets/ui.notifications.info("Add Eqassets/uipment functionality - implement item browser/compendium");
  });
}

/**
 * Handle add feat button
 */
export function initializeAddFeat(html, actor) {
  html.find('.add-feat-btn').on('click', async (event) => {
    event.preventDefault();
    
    if (!actor) return;

    assets/ui.notifications.info("Add Feat functionality - implement feat browser/compendium");
  });
}

/**
 * Handle add talent button
 */
export function initializeAddTalent(html, actor) {
  html.find('.add-talent-btn').on('click', async (event) => {
    event.preventDefault();
    
    if (!actor) return;

    assets/ui.notifications.info("Add Talent functionality - implement talent browser/compendium");
  });
}

/**
 * Handle add power button
 */
export function initializeAddPower(html, actor) {
  html.find('.add-power-btn').on('click', async (event) => {
    event.preventDefault();
    
    if (!actor) return;

    assets/ui.notifications.info("Add Force Power functionality - implement power browser/compendium");
  });
}

/**
 * Handle item view buttons
 */
export function initializeItemView(html, actor) {
  html.find('.item-btn-sm').on('click', async (event) => {
    event.preventDefault();
    const button = $(event.currentTarget);
    const itemId = button.data('item-id');
    
    if (!actor) return;

    const item = actor.items.get(itemId);
    if (item) {
      item.sheet.render(true);
    } else {
      assets/ui.notifications.warn("Item not found");
    }
  });
}

/**
 * Master initialization function
 * Call this from your ActorSheet activateListeners
 */
export function activateSheetListeners(html, sheet) {
  const actor = sheet.actor;

  // Initialize all handlers
  initializeSheetHandlers(html, actor);
  initializeInitiativeRoll(html, actor);
  initializePortraitClick(html, actor);
  initializeAddEqassets/uipment(html, actor);
  initializeAddFeat(html, actor);
  initializeAddTalent(html, actor);
  initializeAddPower(html, actor);
  initializeItemView(html, actor);

  console.log("SWSE Character Sheet listeners activated");
}

/**
 * Example usage in your ActorSheet class:
 * 
 * class SWSEActorSheet extends ActorSheet {
 *   activateListeners(html) {
 *     super.activateListeners(html);
 *     
 *     // Import and use the handler
 *     import { activateSheetListeners } from './path/to/sheet-handlers.js';
 *     activateSheetListeners(html, this);
 *   }
 * }
 */
