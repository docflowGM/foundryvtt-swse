
// Auto-generated partial loader for Foundry V12+
export function registerSWSEPartials() {
  const paths = [
    "systems/foundryvtt-swse/templates/partials/actor/persistent-header.hbs",
    "systems/foundryvtt-swse/templates/partials/ui/condition-track.hbs",
    "systems/foundryvtt-swse/templates/partials/ability-block.hbs",
    "systems/foundryvtt-swse/templates/partials/ability-scores.hbs",
    "systems/foundryvtt-swse/templates/partials/defenses.hbs",
    "systems/foundryvtt-swse/templates/partials/skill-row.hbs",
    "systems/foundryvtt-swse/templates/partials/tab-navigation.hbs",
    "systems/foundryvtt-swse/templates/partials/item-controls.hbs"
  ];

  for (const path of paths) {
    const name = path.split("/").pop().replace(".hbs", "");
    const tpl = foundry.templates.get(path);
    if (tpl) {
      Handlebars.registerPartial(name, tpl);
      swseLogger.log(`SWSE | Registered partial: ${name}`);
    } else {
      swseLogger.warn(`SWSE | Missing partial template: ${path}`);
    }
  }
}
